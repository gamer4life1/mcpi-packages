#!/bin/bash

set -e

export MCPI_MODE="server"
export USER_UID="$(id -u)"
export USER_GID="$(id -g)"

rm -rf /tmp/minecraft-pi
mkdir -p /tmp/minecraft-pi

touch /tmp/minecraft-pi/main.log
tail -f /tmp/minecraft-pi/main.log &
TAIL_PID=$!

cd /app/minecraft-pi

export MCPI_ROOT="${PWD}"

./launcher

kill -9 $TAIL_PID
